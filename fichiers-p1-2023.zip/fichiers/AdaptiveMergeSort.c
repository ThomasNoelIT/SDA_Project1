/* ========================================================================= *
 * AdaptiveMergeSort
 * Implementation of the Adaptive Merge Sort algorithm.
 * ========================================================================= */

#include "Sort.h"
#include "Array.h"

int findRun(int* array, size_t start, size_t end, size_t minSize);

int findRun(int* array, size_t start, size_t end, size_t minSize) {

    // to be completed
    return start;
}

void sort(int *array, size_t length) {

    // to be completed
    return;
}
