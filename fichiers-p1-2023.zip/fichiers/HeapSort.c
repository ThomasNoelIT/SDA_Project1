/* ========================================================================= *
 * HeapSort
 * Implementation of the HeapSort algorithm.
 * ========================================================================= */

#include "Sort.h"
#include "Array.h"

void sort(int* array, size_t length)
{
    // To be completed
    return;
}
